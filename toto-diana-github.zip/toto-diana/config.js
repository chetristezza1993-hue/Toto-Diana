// Incolla qui la configurazione WEB della tua app Firebase (non è una password segreta).
export const firebaseConfig = {
  apiKey: 'INSERISCI_API_KEY',
  authDomain: 'INSERISCI_PROJECT_ID.firebaseapp.com',
  projectId: 'INSERISCI_PROJECT_ID',
  appId: 'INSERISCI_APP_ID'
};
